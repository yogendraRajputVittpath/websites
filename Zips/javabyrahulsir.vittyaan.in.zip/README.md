# Rahul Yadav Java Coaching - Official Website

## 🎯 About
Professional static website for Rahul Yadav Java Coaching, a leading Java training institute in Khandari, Agra.

## 🚀 Features
- **Fully Responsive** - Works on all devices
- **SEO Optimized** - Meta tags, sitemap, schema markup
- **Fast Loading** - Optimized images and code
- **Modern Design** - Deep Navy Blue + Gold theme
- **Smooth Animations** - jQuery-powered interactions
- **Contact Forms** - Easy inquiry submission
- **Blog Section** - Educational content
- **WhatsApp Integration** - Quick communication

## 📁 File Structure
```
website/
├── index.html          # Home page
├── about.html          # About page
├── courses.html        # Courses page
├── placements.html     # Placements page
├── blog.html           # Blog page
├── contact.html        # Contact page
├── sitemap.xml         # SEO sitemap
├── robots.txt          # Search engine instructions
├── .htaccess          # Apache configuration
├── css/
│   └── style.css      # Custom styles
├── js/
│   └── main.js        # jQuery animations
└── images/            # Image assets
```

## 🛠️ Technologies Used
- **HTML5** - Semantic markup
- **CSS3** - Custom styling with animations
- **Bootstrap 5** - Responsive framework
- **JavaScript** - Interactive features
- **jQuery 3.7.1** - DOM manipulation and animations
- **Font Awesome 6** - Icons
- **Google Fonts** - Inter typography

## 📱 Pages
1. **Home** - Hero, programs, stats, testimonials
2. **About** - Trainer profile, methodology, vision
3. **Courses** - 5 detailed course programs
4. **Placements** - Success stories, placement stats
5. **Blog** - Java tutorials and career advice
6. **Contact** - Form, map, contact information

## 🎨 Design Theme
- **Primary Color:** Deep Navy Blue (#0A1F44)
- **Accent Color:** Gold (#D4AF37)
- **Typography:** Inter (Google Fonts)
- **Style:** Professional, modern, tech-inspired

## 📞 Contact Information
- **Phone:** 895880004
- **Email:** rahulsir.java@gmail.com
- **Location:** Khandari, Agra, Uttar Pradesh
- **WhatsApp:** +91 895880004

## 🚀 Deployment Instructions

### For Shared Hosting:
1. Upload all files to public_html or www folder
2. Ensure .htaccess is uploaded
3. Set proper file permissions (644 for files, 755 for folders)
4. Access via your domain: yoursite.com

### For cPanel:
1. Login to cPanel
2. Use File Manager
3. Upload ZIP and extract
4. Update sitemap.xml with your actual domain

### For FTP:
1. Use FileZilla or any FTP client
2. Connect to your hosting
3. Upload all files maintaining folder structure

## ⚙️ Configuration

### Update Domain:
Edit `sitemap.xml` and replace `www.rahulyadavjava.com` with your actual domain.

### Update Contact Details:
If contact info changes, update in:
- All HTML files (footer section)
- contact.html (main content)
- js/main.js (floating buttons)

### Enable HTTPS:
Uncomment HTTPS redirect in `.htaccess` after SSL installation.

## 🔧 Customization

### Colors:
Edit CSS variables in `css/style.css`:
```css
:root {
    --primary-navy: #0A1F44;
    --gold: #D4AF37;
    /* ... */
}
```

### Content:
Edit HTML files directly. All content is in plain HTML.

### Images:
Replace image URLs in HTML files with your own images.

## 📈 SEO Features
- Meta titles and descriptions on all pages
- Schema.org structured data (Local Business)
- XML sitemap
- Robots.txt
- SEO-friendly URLs
- Alt tags on all images
- Fast loading time
- Mobile-responsive

## ✅ Browser Compatibility
- Chrome (Latest)
- Firefox (Latest)
- Safari (Latest)
- Edge (Latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📊 Performance
- Lightweight CSS and JS
- CDN-hosted libraries
- Image optimization
- Browser caching enabled
- GZIP compression

## 🔒 Security
- No backend vulnerabilities (static site)
- Security headers in .htaccess
- Form validation
- XSS protection

## 📝 License
All rights reserved - Rahul Yadav Java Coaching © 2024

## 👨‍💻 Support
For technical support or customization requests:
- Email: rahulsir.java@gmail.com
- Phone: 895880004

---

**Built with ❤️ for Java Education in Agra**