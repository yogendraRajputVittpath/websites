/* ===========================================
   RAHUL YADAV JAVA COACHING - MAIN JS
   jQuery animations and interactions
   =========================================== */

$(document).ready(function() {
    
    // ========== NAVBAR SCROLL EFFECT ==========
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            $('.navbar').addClass('scrolled');
        } else {
            $('.navbar').removeClass('scrolled');
        }
    });

    // ========== SMOOTH SCROLLING ==========
    $('a[href^="#"]').on('click', function(e) {
        var target = $(this.getAttribute('href'));
        if(target.length) {
            e.preventDefault();
            $('html, body').stop().animate({
                scrollTop: target.offset().top - 80
            }, 1000);
        }
    });

    // ========== ANIMATED COUNTERS ==========
    function animateCounter(element) {
        var $this = $(element);
        var countTo = $this.attr('data-target');
        
        $({ countNum: 0 }).animate({
            countNum: countTo
        },
        {
            duration: 2000,
            easing: 'swing',
            step: function() {
                $this.text(Math.floor(this.countNum));
            },
            complete: function() {
                $this.text(this.countNum);
            }
        });
    }

    // Trigger counters when in viewport
    var counterAnimated = false;
    $(window).scroll(function() {
        if ($('.counter').length) {
            var counterTop = $('.counter').first().offset().top;
            var counterBottom = counterTop + $('.counter').first().outerHeight();
            var scrollTop = $(window).scrollTop();
            var windowHeight = $(window).height();
            
            if (!counterAnimated && scrollTop + windowHeight > counterTop) {
                counterAnimated = true;
                $('.counter').each(function() {
                    animateCounter(this);
                });
            }
        }
    });

    // ========== SCROLL ANIMATIONS ==========
    function checkScroll() {
        $('.fade-in-up').each(function() {
            var elementTop = $(this).offset().top;
            var elementBottom = elementTop + $(this).outerHeight();
            var viewportTop = $(window).scrollTop();
            var viewportBottom = viewportTop + $(window).height();
            
            if (elementBottom > viewportTop && elementTop < viewportBottom) {
                $(this).addClass('visible');
            }
        });

        // Animate program cards
        $('.program-card').each(function(i) {
            var elementTop = $(this).offset().top;
            var viewportBottom = $(window).scrollTop() + $(window).height();
            
            if (elementTop < viewportBottom - 100) {
                setTimeout(() => {
                    $(this).css({
                        'opacity': '1',
                        'transform': 'translateY(0)'
                    });
                }, i * 100);
            }
        });
    }

    // Initialize program cards
    $('.program-card').css({
        'opacity': '0',
        'transform': 'translateY(30px)',
        'transition': 'all 0.5s ease'
    });

    $(window).on('scroll', checkScroll);
    checkScroll(); // Initial check

    // ========== CAROUSEL AUTO-PLAY ==========
    if ($('.carousel').length) {
        $('.carousel').carousel({
            interval: 5000,
            pause: 'hover'
        });
    }

    // ========== FORM HANDLING ==========
    $('#quickContactForm, #contactForm').on('submit', function(e) {
        e.preventDefault();
        
        // Show success message
        $('#formSuccess').slideDown();
        
        // Reset form
        this.reset();
        
        // Hide success message after 5 seconds
        setTimeout(function() {
            $('#formSuccess').slideUp();
        }, 5000);
        
        // In production, add AJAX call here to submit form data
        // $.ajax({...});
    });

    // ========== MOBILE MENU CLOSE ON CLICK ==========
    $('.navbar-nav a').on('click', function() {
        if ($(window).width() < 992) {
            $('.navbar-collapse').collapse('hide');
        }
    });

    // ========== HOVER EFFECTS FOR CARDS ==========
    $('.program-card, .methodology-card, .placement-stat-card').hover(
        function() {
            $(this).css('transform', 'translateY(-10px)');
        },
        function() {
            $(this).css('transform', 'translateY(0)');
        }
    );

    // ========== BACK TO TOP BUTTON ==========
    // Create back to top button
    $('body').append('<a href="#" class="back-to-top" style="display: none;"><i class="fas fa-arrow-up"></i></a>');
    
    // Add styles
    $('.back-to-top').css({
        'position': 'fixed',
        'bottom': '150px',
        'right': '20px',
        'width': '45px',
        'height': '45px',
        'background': '#0A1F44',
        'color': '#D4AF37',
        'border-radius': '50%',
        'text-align': 'center',
        'line-height': '45px',
        'font-size': '1.2rem',
        'z-index': '999',
        'cursor': 'pointer',
        'transition': 'all 0.3s ease',
        'box-shadow': '0 4px 15px rgba(0,0,0,0.3)'
    });

    // Show/hide on scroll
    $(window).scroll(function() {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn();
        } else {
            $('.back-to-top').fadeOut();
        }
    });

    // Scroll to top on click
    $('.back-to-top').click(function(e) {
        e.preventDefault();
        $('html, body').animate({scrollTop: 0}, 800);
    });

    // Hover effect
    $('.back-to-top').hover(
        function() {
            $(this).css({
                'background': '#D4AF37',
                'color': '#0A1F44',
                'transform': 'scale(1.1)'
            });
        },
        function() {
            $(this).css({
                'background': '#0A1F44',
                'color': '#D4AF37',
                'transform': 'scale(1)'
            });
        }
    );

    // ========== LOADING ANIMATION ==========
    $(window).on('load', function() {
        // Trigger animations after page load
        setTimeout(function() {
            $('.hero-content').addClass('visible');
        }, 200);
    });

    // ========== PARALLAX EFFECT FOR HERO ==========
    $(window).scroll(function() {
        var scrolled = $(window).scrollTop();
        if ($('.hero-section').length) {
            $('.hero-section').css('background-position', 'center ' + (scrolled * 0.5) + 'px');
        }
    });

    // ========== FORM VALIDATION ==========
    $('input[type="tel"]').on('input', function() {
        this.value = this.value.replace(/[^0-9]/g, '');
        if (this.value.length > 10) {
            this.value = this.value.slice(0, 10);
        }
    });

    // ========== IMAGE LAZY LOADING ==========
    if ('IntersectionObserver' in window) {
        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    img.src = img.dataset.src || img.src;
                    img.classList.add('loaded');
                    observer.unobserve(img);
                }
            });
        });

        document.querySelectorAll('img').forEach(img => {
            imageObserver.observe(img);
        });
    }

    // ========== COURSE CARD ANIMATIONS ==========
    $('.course-detail-card').each(function(i) {
        $(this).css({
            'opacity': '0',
            'transform': 'translateY(30px)'
        });
    });

    $(window).scroll(function() {
        $('.course-detail-card').each(function(i) {
            var elementTop = $(this).offset().top;
            var viewportBottom = $(window).scrollTop() + $(window).height();
            
            if (elementTop < viewportBottom - 100) {
                setTimeout(() => {
                    $(this).css({
                        'opacity': '1',
                        'transform': 'translateY(0)',
                        'transition': 'all 0.6s ease'
                    });
                }, i * 200);
            }
        });
    });

    // ========== BLOG POST ANIMATIONS ==========
    if ($('.blog-post-card').length) {
        $('.blog-post-card').each(function(i) {
            $(this).css({
                'opacity': '0',
                'transform': 'translateY(30px)'
            });
        });

        $(window).scroll(function() {
            $('.blog-post-card').each(function(i) {
                var elementTop = $(this).offset().top;
                var viewportBottom = $(window).scrollTop() + $(window).height();
                
                if (elementTop < viewportBottom - 50) {
                    setTimeout(() => {
                        $(this).css({
                            'opacity': '1',
                            'transform': 'translateY(0)',
                            'transition': 'all 0.5s ease'
                        });
                    }, i * 100);
                }
            });
        });
    }

    // ========== SUCCESS STORY CARDS ANIMATION ==========
    if ($('.success-story-card').length) {
        $('.success-story-card').each(function(i) {
            $(this).css({
                'opacity': '0',
                'transform': 'scale(0.9)'
            });
        });

        $(window).scroll(function() {
            $('.success-story-card').each(function(i) {
                var elementTop = $(this).offset().top;
                var viewportBottom = $(window).scrollTop() + $(window).height();
                
                if (elementTop < viewportBottom - 50) {
                    setTimeout(() => {
                        $(this).css({
                            'opacity': '1',
                            'transform': 'scale(1)',
                            'transition': 'all 0.5s ease'
                        });
                    }, i * 100);
                }
            });
        });
    }

    // ========== NAVBAR ACTIVE STATE ==========
    // Get current page URL
    var currentPage = window.location.pathname.split('/').pop();
    
    // Remove active class from all nav links
    $('.navbar-nav .nav-link').removeClass('active');
    
    // Add active class to current page link
    if (currentPage) {
        $('.navbar-nav .nav-link[href="' + currentPage + '"]').addClass('active');
    } else {
        $('.navbar-nav .nav-link[href="index.html"]').addClass('active');
    }

    // ========== PREVENT DEFAULT FOR EMPTY LINKS ==========
    $('a[href="#"]').on('click', function(e) {
        if ($(this).attr('href') === '#') {
            e.preventDefault();
        }
    });

    // ========== CONSOLE MESSAGE ==========
    console.log('%c🚀 Rahul Yadav Java Coaching', 'color: #D4AF37; font-size: 24px; font-weight: bold;');
    console.log('%c💻 Master Java & Build Your IT Career', 'color: #0A1F44; font-size: 16px;');
    console.log('%c📞 Call: 895880004', 'color: #666; font-size: 14px;');

}); // End document ready


// ========== PREVENT CONTEXT MENU (Optional - for production) ==========
// Uncomment below to prevent right-click (optional security measure)
/*
document.addEventListener('contextmenu', function(e) {
    e.preventDefault();
});
*/

// ========== PRINT PAGE TITLE ==========
window.onload = function() {
    console.log('Website loaded successfully!');
};
