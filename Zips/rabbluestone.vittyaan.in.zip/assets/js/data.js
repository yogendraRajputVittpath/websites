/* ==========================================================================
   RAB Bluestone — Data Store (Properties + Blog)
   ========================================================================== */

window.RAB_PROPERTIES = [
  {
    id: "rab-bluestone-city",
    name: "RAB Bluestone City",
    type: "Residential Plots",
    category: "residential",
    location: "Naini, Prayagraj",
    price: "Starting ₹ 14.5 Lakhs",
    short: "A premium gated plotted township offering well-planned residential plots with modern infrastructure and strong appreciation potential.",
    badge: "Flagship",
    images: [
      "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1493809842364-78817add7ffb?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1572120360610-d971b9d7767c?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=1200&q=80&auto=format&fit=crop"
    ],
    overview: "RAB Bluestone City is our flagship plotted development in Naini, Prayagraj. Designed for families and investors who value transparency, infrastructure quality, and long-term value, the project offers thoughtfully laid out residential plots within a secure, gated environment. With wide internal roads, organised green pockets, and convenient access to the Naini–Karchana corridor, RAB Bluestone City is positioned to benefit from Prayagraj's ongoing infrastructure growth.",
    features: ["Gated boundary wall with controlled entry", "Wide internal roads with paving", "Underground utility planning", "Designated green pockets & open spaces", "Street lighting throughout the township", "Plot demarcation with corner markers"],
    amenities: ["24/7 security plan", "Wide internal roads", "Street lighting", "Rainwater harvesting", "Green common spaces", "Park area", "Pavement walkways", "Designated parking zones"],
    locationDesc: "Located in Naini, one of the fastest growing extensions of Prayagraj, with easy access to NH-2, the Yamuna bridge, IIIT Allahabad, and key institutional zones.",
    highlights: [
      { i: "fa-ruler-combined", v: "1000 sq.ft+", k: "Plot Sizes" },
      { i: "fa-road", v: "30 ft", k: "Internal Roads" },
      { i: "fa-tree", v: "20%", k: "Green Cover" },
      { i: "fa-shield-halved", v: "24/7", k: "Security" }
    ]
  },
  {
    id: "rab-green-residency",
    name: "RAB Green Residency",
    type: "Residential Apartments",
    category: "residential",
    location: "Jhunsi, Prayagraj",
    price: "Starting ₹ 32 Lakhs",
    short: "Modern apartment community at Jhunsi with thoughtfully designed homes, family-friendly amenities, and strong connectivity.",
    badge: "New Launch",
    images: [
      "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1502005229762-cf1b2da7c5d6?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=1200&q=80&auto=format&fit=crop"
    ],
    overview: "RAB Green Residency offers contemporary 2 and 3 BHK apartments designed for families that value space, light, and lifestyle. Located in Jhunsi—an established residential pocket of Prayagraj—the project provides a balanced mix of comfort and connectivity with proximity to schools, healthcare, and the Sangam region.",
    features: ["Vaastu-aligned 2 & 3 BHK layouts", "Large balconies with cross ventilation", "Premium vitrified flooring", "Modular kitchen-ready plumbing", "Lift and power backup", "Dedicated children's play area"],
    amenities: ["Clubhouse", "Landscaped gardens", "Children's play zone", "Gymnasium", "Lift access", "Power backup", "Covered parking", "CCTV surveillance"],
    locationDesc: "Jhunsi is a well-developed residential belt of Prayagraj with strong civic amenities, easy access to the Allahabad–Varanasi highway, and proximity to the Sangam.",
    highlights: [
      { i: "fa-bed", v: "2 & 3 BHK", k: "Configurations" },
      { i: "fa-building", v: "G+5", k: "Tower Plan" },
      { i: "fa-square-parking", v: "Covered", k: "Parking" },
      { i: "fa-bolt", v: "100%", k: "Power Backup" }
    ]
  },
  {
    id: "rab-elite-enclave",
    name: "RAB Elite Enclave",
    type: "Independent Villas",
    category: "residential",
    location: "Civil Lines, Prayagraj",
    price: "On Request",
    short: "An exclusive enclave of premium independent villas in the heart of Civil Lines, designed for buyers seeking privacy and stature.",
    badge: "Premium",
    images: [
      "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=1200&q=80&auto=format&fit=crop"
    ],
    overview: "RAB Elite Enclave brings together a limited collection of independent villas in Civil Lines, Prayagraj's most prestigious address. Crafted for discerning buyers, each villa offers private gardens, double-height living spaces, and contemporary architecture that blends elegance with everyday liveability.",
    features: ["Independent G+1 villas", "Private gardens", "Double-height entrance lobby", "Premium imported fittings", "Servant quarter option", "Covered car porch"],
    amenities: ["Private garden", "Car porch", "Servant quarter", "Modular kitchen", "Solar provision", "Boundary security", "Premium fittings", "Vaastu compliant"],
    locationDesc: "Civil Lines is the established premium address of Prayagraj, with access to leading schools, hospitals, the High Court, and key administrative centres.",
    highlights: [
      { i: "fa-house-chimney", v: "4 BHK", k: "Configuration" },
      { i: "fa-vector-square", v: "2400 sq.ft+", k: "Built-up" },
      { i: "fa-leaf", v: "Private", k: "Garden" },
      { i: "fa-car", v: "Covered", k: "Car Porch" }
    ]
  },
  {
    id: "rab-prime-commercial-hub",
    name: "RAB Prime Commercial Hub",
    type: "Commercial Shops",
    category: "commercial",
    location: "Sulemsarai, Prayagraj",
    price: "Starting ₹ 22 Lakhs",
    short: "Strategic high-street commercial spaces at Sulemsarai for retailers, brands, and investors seeking strong footfall and visibility.",
    badge: "High ROI",
    images: [
      "https://images.unsplash.com/photo-1554435493-93422e8220c8?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1604328698692-f76ea9498e76?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=1200&q=80&auto=format&fit=crop"
    ],
    overview: "RAB Prime Commercial Hub is a thoughtfully planned high-street retail destination at Sulemsarai, with prominent frontage units suitable for showrooms, food & beverage, banking, and professional offices. The project's design prioritises footfall, visibility, and an efficient mix of retail and office formats.",
    features: ["Ground & first floor retail units", "Wide store frontages", "High ceiling heights", "Service lift provision", "Ample customer parking", "Power backup for common areas"],
    amenities: ["Customer parking", "Power backup", "Service lift", "Loading bay", "CCTV surveillance", "Common washrooms", "Façade signage zones", "High-visibility frontage"],
    locationDesc: "Sulemsarai is a high-density commercial belt of Prayagraj with established retail demand and consistent vehicular and pedestrian footfall.",
    highlights: [
      { i: "fa-store", v: "Retail", k: "Use Case" },
      { i: "fa-arrows-up-down-left-right", v: "Wide", k: "Frontage" },
      { i: "fa-people-roof", v: "High", k: "Footfall" },
      { i: "fa-square-parking", v: "Ample", k: "Parking" }
    ]
  },
  {
    id: "rab-golden-meadows",
    name: "RAB Golden Meadows",
    type: "Farm Land",
    category: "agricultural",
    location: "Kaudhiyara, Prayagraj",
    price: "Starting ₹ 6.5 Lakhs/acre",
    short: "Carefully selected agricultural and farm land parcels at Kaudhiyara, ideal for farmhouses, organic farming, and long-term land investment.",
    badge: "Investment",
    images: [
      "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1500595046743-cd271d694d30?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1444858345400-fbc1c46d7ec1?w=1200&q=80&auto=format&fit=crop"
    ],
    overview: "RAB Golden Meadows is a curated set of agricultural land parcels at Kaudhiyara, offered with verified records and clear demarcation. The location is suited to buyers exploring weekend farmhouses, organic cultivation, or long-horizon land banking outside the city core.",
    features: ["Verified land records", "Clear demarcation", "Approach road access", "Suitable for orchards / farmhouses", "Sizes from 0.5 to 5 acres", "Long-term holding potential"],
    amenities: ["Approach road", "Border demarcation", "Water source nearby", "Electrical line access", "Cultivable soil profile", "Quiet surroundings", "Distance from city pollution", "Long-horizon potential"],
    locationDesc: "Kaudhiyara lies along Prayagraj's outer belt with quiet surroundings, agricultural neighbourhoods, and improving road connectivity towards the city.",
    highlights: [
      { i: "fa-tractor", v: "Agri", k: "Use" },
      { i: "fa-mountain-sun", v: "Quiet", k: "Surroundings" },
      { i: "fa-water", v: "Available", k: "Water Source" },
      { i: "fa-file-contract", v: "Verified", k: "Records" }
    ]
  },
  {
    id: "rab-orchid-residency",
    name: "RAB Orchid Residency",
    type: "Residential Flats",
    category: "residential",
    location: "Naini, Prayagraj",
    price: "Starting ₹ 26 Lakhs",
    short: "Affordable, well-designed 2 BHK flats in Naini—ideal for first-time home buyers and small families.",
    badge: "Family Homes",
    images: [
      "https://images.unsplash.com/photo-1560448204-603b3fc33ddc?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1502672023488-70e25813eb80?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1503174971373-b1f69850bded?w=1200&q=80&auto=format&fit=crop",
      "https://images.unsplash.com/photo-1505691938895-1758d7feb511?w=1200&q=80&auto=format&fit=crop"
    ],
    overview: "RAB Orchid Residency offers comfortable 2 BHK apartments built around natural light, ventilation, and efficient space planning. Positioned in Naini, the project gives families a practical entry into branded housing without compromising on essential amenities.",
    features: ["Spacious 2 BHK layouts", "Cross ventilation", "Premium tile flooring", "Lift access", "Power backup for common areas", "Children's play space"],
    amenities: ["Lift", "Power backup", "Children's play zone", "Common garden", "Visitor parking", "CCTV at entrance", "Intercom provision", "Water storage"],
    locationDesc: "Naini is rapidly developing into a key residential extension of Prayagraj, supported by the Naini bridge, NH-2, and growing institutional infrastructure.",
    highlights: [
      { i: "fa-bed", v: "2 BHK", k: "Configuration" },
      { i: "fa-building", v: "G+4", k: "Tower Plan" },
      { i: "fa-elevator", v: "Yes", k: "Lift" },
      { i: "fa-bolt", v: "Backup", k: "Power" }
    ]
  }
];

window.RAB_BLOG = [
  { slug: "best-areas-to-invest-in-prayagraj", title: "Best Areas to Invest in Prayagraj in 2026", cat: "Investment", date: "12 February 2026", read: "7 min read", image: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=1200&q=80&auto=format&fit=crop", excerpt: "From Naini to Jhunsi, here is a practical guide to Prayagraj's growth corridors and what makes each area attractive for long-term real estate investment." },
  { slug: "residential-vs-commercial-property", title: "Residential vs Commercial Property: Which Is Right for You?", cat: "Buyer Guide", date: "08 February 2026", read: "6 min read", image: "https://images.unsplash.com/photo-1554435493-93422e8220c8?w=1200&q=80&auto=format&fit=crop", excerpt: "A balanced comparison of risk, returns, liquidity, and ownership effort across residential and commercial real estate investments." },
  { slug: "property-registration-process-uttar-pradesh", title: "Property Registration Process in Uttar Pradesh: A Step-by-Step Guide", cat: "Legal", date: "02 February 2026", read: "8 min read", image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=1200&q=80&auto=format&fit=crop", excerpt: "Understand the complete registration workflow in UP—from stamp duty calculation to sub-registrar visit—explained in simple language." },
  { slug: "understanding-circle-rates", title: "Understanding Circle Rates and Their Impact on Property Buyers", cat: "Pricing", date: "27 January 2026", read: "5 min read", image: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=1200&q=80&auto=format&fit=crop", excerpt: "Circle rates set the floor for stamp duty—but what they really mean for your final acquisition cost is often misunderstood. Here is a clear explanation." },
  { slug: "how-to-verify-property-documents", title: "How to Verify Property Documents Before You Buy", cat: "Due Diligence", date: "21 January 2026", read: "9 min read", image: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=1200&q=80&auto=format&fit=crop", excerpt: "A checklist-driven approach to title verification, chain of ownership, encumbrance, and statutory approvals you should review before committing." },
  { slug: "home-buying-checklist", title: "The Complete Home Buying Checklist for First-Time Buyers", cat: "Buyer Guide", date: "16 January 2026", read: "6 min read", image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200&q=80&auto=format&fit=crop", excerpt: "From budgeting and loan eligibility to final possession, here is a structured checklist for buyers stepping into the market for the first time." },
  { slug: "real-estate-investment-for-beginners", title: "Real Estate Investment for Beginners: Where to Start", cat: "Investment", date: "10 January 2026", read: "7 min read", image: "https://images.unsplash.com/photo-1518780664697-55e3ad937233?w=1200&q=80&auto=format&fit=crop", excerpt: "If you are new to property investing, here is a measured framework to think about goals, holding period, leverage, and asset selection." },
  { slug: "agricultural-land-investment-guide", title: "Agricultural Land Investment: What Buyers in UP Should Know", cat: "Land", date: "03 January 2026", read: "8 min read", image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1200&q=80&auto=format&fit=crop", excerpt: "Buying farm land has its own legal, taxation, and use-case nuances in Uttar Pradesh. We break down what every prospective buyer should evaluate." },
  { slug: "commercial-property-investment-strategies", title: "Commercial Property Investment Strategies for Indian Investors", cat: "Investment", date: "28 December 2025", read: "7 min read", image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=1200&q=80&auto=format&fit=crop", excerpt: "Understand the levers behind commercial real estate returns—location, tenant profile, lease structure, and exit strategy—before committing capital." },
  { slug: "important-legal-documents-before-property-purchase", title: "Important Legal Documents to Review Before a Property Purchase", cat: "Legal", date: "22 December 2025", read: "6 min read", image: "https://images.unsplash.com/photo-1521791136064-7986c2920216?w=1200&q=80&auto=format&fit=crop", excerpt: "Sale deed, mother deed, encumbrance certificate, mutation records—we explain each document and what to look for inside it." },
  { slug: "future-growth-areas-of-prayagraj", title: "Future Growth Areas of Prayagraj: Where to Watch", cat: "Market Trends", date: "15 December 2025", read: "6 min read", image: "https://images.unsplash.com/photo-1496564203457-11bb12075d90?w=1200&q=80&auto=format&fit=crop", excerpt: "Infrastructure decisions reshape neighbourhoods. Here are the corridors and pockets of Prayagraj that look interesting for the years ahead." },
  { slug: "property-tax-basics", title: "Property Tax Basics Every Homeowner Should Understand", cat: "Taxation", date: "09 December 2025", read: "5 min read", image: "https://images.unsplash.com/photo-1554224154-22dec7ec8818?w=1200&q=80&auto=format&fit=crop", excerpt: "Annual property tax computation, who pays it, due dates, and the consequences of non-payment—explained without jargon." },
  { slug: "real-estate-market-trends", title: "Indian Real Estate Market Trends to Track This Year", cat: "Market Trends", date: "01 December 2025", read: "7 min read", image: "https://images.unsplash.com/photo-1460472178825-e5240623afd5?w=1200&q=80&auto=format&fit=crop", excerpt: "Mortgage rates, supply pipelines, urbanisation, and policy—a look at the macro variables shaping property prices in the near term." },
  { slug: "benefits-of-investing-in-plotted-developments", title: "Benefits of Investing in Plotted Developments", cat: "Land", date: "24 November 2025", read: "6 min read", image: "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=1200&q=80&auto=format&fit=crop", excerpt: "Plotted projects sit between raw land and built-up property in risk and reward. Here is how to evaluate them objectively." },
  { slug: "how-to-evaluate-land-value", title: "How to Evaluate the Real Value of a Piece of Land", cat: "Pricing", date: "17 November 2025", read: "7 min read", image: "https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=1200&q=80&auto=format&fit=crop", excerpt: "Beyond the asking price—how to triangulate land value using circle rate, recent transactions, infrastructure, and use-case potential." },
  { slug: "real-estate-due-diligence", title: "Real Estate Due Diligence: A Complete Buyer's Framework", cat: "Due Diligence", date: "10 November 2025", read: "9 min read", image: "https://images.unsplash.com/photo-1554224154-26032ffc0d07?w=1200&q=80&auto=format&fit=crop", excerpt: "Title, technical, legal, taxation, encumbrance, and physical inspection—a structured framework to evaluate any property before you buy." },
  { slug: "common-property-buying-mistakes", title: "Common Property Buying Mistakes (and How to Avoid Them)", cat: "Buyer Guide", date: "03 November 2025", read: "6 min read", image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200&q=80&auto=format&fit=crop", excerpt: "From skipping legal review to misreading the floor plan—here are the most expensive mistakes buyers make, and how to sidestep them." },
  { slug: "home-loan-basics", title: "Home Loan Basics: EMI, Eligibility & Tax Benefits", cat: "Finance", date: "26 October 2025", read: "7 min read", image: "https://images.unsplash.com/photo-1554224155-3a589877462b?w=1200&q=80&auto=format&fit=crop", excerpt: "Understand how lenders evaluate you, how EMIs are computed, and the tax benefits available under Indian income tax law for home loans." },
  { slug: "rental-yield-explained", title: "Rental Yield Explained: A Practical Guide", cat: "Investment", date: "19 October 2025", read: "5 min read", image: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=1200&q=80&auto=format&fit=crop", excerpt: "Gross yield, net yield, and total return—how to think about cash flow from rental property in Indian cities." },
  { slug: "long-term-wealth-creation-through-real-estate", title: "Long-Term Wealth Creation Through Real Estate", cat: "Investment", date: "12 October 2025", read: "8 min read", image: "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=1200&q=80&auto=format&fit=crop", excerpt: "Real estate has historically been a foundational wealth-building asset for Indian households. Here is how to think about it strategically." }
];

window.RAB_BLOG_BODY = `
<p class="lead">The Indian real estate market has long served as one of the most dependable vehicles for wealth creation, capital preservation, and intergenerational planning. For buyers and investors operating in regional growth centres like Prayagraj, a measured and well-informed approach can make the difference between an average outcome and a genuinely rewarding one.</p>

<p>In this article we walk through the practical considerations that thoughtful buyers should keep in mind—drawing on our day-to-day work with families, investors, and business owners across Prayagraj and the wider Uttar Pradesh region.</p>

<h2>Why a Structured Approach Matters</h2>

<p>Real estate is, in most cases, the single largest financial commitment a household will make. The decision deserves the same level of rigour you would apply to any major investment: clear objectives, careful research, professional input where required, and a long-term outlook.</p>

<p>Buyers who treat real estate as a casual decision often end up either overpaying for an average asset or holding a property they later struggle to monetise. Buyers who approach the same decision with structure tend to acquire well, hold confidently, and exit on their own terms.</p>

<blockquote>"The best time to plant a tree was twenty years ago. The second best time is today." — and the same is broadly true of well-chosen real estate, provided the underlying location, paperwork, and fundamentals are sound.</blockquote>

<h2>Key Factors to Evaluate</h2>

<p>Whether you are buying a residential plot, an apartment, a commercial unit, or agricultural land, a few core variables consistently shape the outcome of any property purchase:</p>

<ul>
  <li><strong>Location & connectivity</strong> — the single most important driver of long-term value.</li>
  <li><strong>Title & documentation</strong> — clean, verifiable, and free of encumbrance.</li>
  <li><strong>Approvals & compliance</strong> — local authority approvals, layout sanction, land use, and statutory clearances.</li>
  <li><strong>Builder/seller credibility</strong> — track record, delivery history, and reputation in the local market.</li>
  <li><strong>Use-case fit</strong> — does the property align with your intended use, holding period, and exit plan?</li>
  <li><strong>Pricing benchmark</strong> — circle rate, recent comparable transactions, and current market sentiment.</li>
</ul>

<h2>Working with Local Expertise</h2>

<p>Markets like Prayagraj have nuances that online listings rarely capture—micro-market preferences, road widening plans, school catchments, upcoming institutional projects, and the difference between a "good street" and a "great street" within the same neighbourhood. Working with a transparent, locally-rooted real estate partner helps surface this context early and reduces the chances of an avoidable mistake.</p>

<h3>What a Good Partner Brings</h3>

<ol>
  <li>Honest, plain-language guidance on price discovery.</li>
  <li>Access to verified inventory across multiple property categories.</li>
  <li>Help with documentation review and registration coordination.</li>
  <li>Site visit logistics and post-purchase support.</li>
  <li>A continued relationship beyond the transaction—useful when you sell, refinance, or invest again.</li>
</ol>

<h2>Final Thoughts</h2>

<p>Real estate rewards patience, preparation, and discipline. There are no shortcuts, and any promise of guaranteed quick returns should be treated with caution. With clear objectives, the right professional support, and an emphasis on transparency at every step, property continues to be one of the most accessible and reliable building blocks of long-term financial stability for Indian families.</p>

<p>If you have a question about a specific property, neighbourhood, or process, the team at RAB Bluestone is happy to help. Our work is built on the long-term relationships we develop with our customers—and we welcome the opportunity to be useful, whether you are buying today or planning twelve months out.</p>
`;
