/* ==========================================================================
   RAB Bluestone — Main JavaScript
   Header/footer injection, interactions, blog/property loading
   ========================================================================== */

(function ($) {
  "use strict";

  // ---------- Brand / Contact ----------
  var BRAND = {
    name: "RAB Bluestone",
    full: "RAB Bluestone Private Limited",
    phone: "+91 8542066197",
    phoneRaw: "918542066197",
    email: "sales@rabbluestonecity.com",
    cin: "U68100UP2026PTC246226",
    head: "14D/4D Chak Daud Nagar, Naini, Prayagraj - 211008",
    branch: "165/144 Sulemsarai, Prayagraj",
    formAction: "https://formsubmit.co/sales@rabbluestonecity.com"
  };
  window.RAB_BRAND = BRAND;

  // ---------- Topbar ----------
  var topbarHTML = `
    <div class="topbar" data-testid="site-topbar">
      <div class="container">
        <div class="tb-left">
          <span class="tb-cin">CIN: ${BRAND.cin}</span>
        </div>
        <div class="tb-right">
          <a href="tel:${BRAND.phoneRaw}" data-testid="topbar-phone"><i class="fa-solid fa-phone"></i> ${BRAND.phone}</a>
          <a href="mailto:${BRAND.email}" data-testid="topbar-email"><i class="fa-solid fa-envelope"></i> ${BRAND.email}</a>
        </div>
      </div>
    </div>`;

  // ---------- Header ----------
  function getCurrentPage() {
    var path = window.location.pathname.split("/").pop() || "index.html";
    return path.toLowerCase();
  }

  function navLink(href, label, testId) {
    var current = getCurrentPage();
    var active = (current === href.toLowerCase()) ? "active" : "";
    return `<a href="${href}" class="${active}" data-testid="${testId}">${label}</a>`;
  }

  var headerHTML = `
    <header class="site-header" data-testid="site-header">
      <div class="container">
        <div class="header-inner">
          <a class="brand" href="index.html" data-testid="site-brand-link">
            <img src="assets/images/logo.png" alt="RAB Bluestone Private Limited Logo" />
          </a>
          <nav class="nav" data-testid="site-nav">
            ${navLink("index.html", "Home", "nav-home")}
            ${navLink("about.html", "About", "nav-about")}
            ${navLink("services.html", "Services", "nav-services")}
            ${navLink("properties.html", "Properties", "nav-properties")}
            ${navLink("blog.html", "Blog", "nav-blog")}
            ${navLink("faq.html", "FAQ", "nav-faq")}
            ${navLink("contact.html", "Contact", "nav-contact")}
          </nav>
          <div class="header-cta">
            <a class="header-phone" href="tel:${BRAND.phoneRaw}" data-testid="header-phone">
              <i class="fa-solid fa-phone"></i>
              <span>${BRAND.phone}</span>
            </a>
            <button class="nav-toggle" aria-label="Open menu" data-testid="nav-toggle-button"><i class="fa-solid fa-bars"></i></button>
          </div>
        </div>
      </div>
    </header>

    <div class="mobile-menu" data-testid="mobile-menu">
      <button class="mm-close" aria-label="Close menu" data-testid="mobile-menu-close-button"><i class="fa-solid fa-xmark"></i></button>
      <a href="index.html" data-testid="mobile-nav-home">Home</a>
      <a href="about.html" data-testid="mobile-nav-about">About</a>
      <a href="services.html" data-testid="mobile-nav-services">Services</a>
      <a href="properties.html" data-testid="mobile-nav-properties">Properties</a>
      <a href="blog.html" data-testid="mobile-nav-blog">Blog</a>
      <a href="faq.html" data-testid="mobile-nav-faq">FAQ</a>
      <a href="contact.html" data-testid="mobile-nav-contact">Contact</a>
      <div class="mm-cta">
        <a class="btn btn-primary" href="tel:${BRAND.phoneRaw}" data-testid="mobile-call-button"><i class="fa-solid fa-phone"></i> Call Us Now</a>
        <a class="btn btn-ghost" href="https://wa.me/${BRAND.phoneRaw}" data-testid="mobile-whatsapp-button"><i class="fa-brands fa-whatsapp"></i> WhatsApp</a>
      </div>
    </div>`;

  // ---------- Footer ----------
  var footerHTML = `
    <footer class="site-footer" data-testid="site-footer">
      <div class="container">
        <div class="footer-grid">
          <div class="footer-col footer-brand">
            <img src="assets/images/logo.png" alt="RAB Bluestone Logo" />
            <p>${BRAND.full} assists individuals, families, and investors in buying, selling, and investing in quality real estate opportunities across Prayagraj and beyond.</p>
            <div class="footer-social">
              <a href="#" aria-label="Facebook" data-testid="footer-social-facebook"><i class="fa-brands fa-facebook-f"></i></a>
              <a href="#" aria-label="Instagram" data-testid="footer-social-instagram"><i class="fa-brands fa-instagram"></i></a>
              <a href="#" aria-label="LinkedIn" data-testid="footer-social-linkedin"><i class="fa-brands fa-linkedin-in"></i></a>
              <a href="#" aria-label="X" data-testid="footer-social-x"><i class="fa-brands fa-x-twitter"></i></a>
              <a href="#" aria-label="YouTube" data-testid="footer-social-youtube"><i class="fa-brands fa-youtube"></i></a>
            </div>
          </div>

          <div class="footer-col">
            <h5>Quick Links</h5>
            <ul>
              <li><a href="index.html">Home</a></li>
              <li><a href="about.html">About Us</a></li>
              <li><a href="services.html">Services</a></li>
              <li><a href="properties.html">Properties</a></li>
              <li><a href="blog.html">Blog</a></li>
              <li><a href="faq.html">FAQ</a></li>
              <li><a href="contact.html">Contact</a></li>
            </ul>
          </div>

          <div class="footer-col">
            <h5>Information</h5>
            <ul>
              <li><a href="privacy-policy.html">Privacy Policy</a></li>
              <li><a href="terms.html">Terms & Conditions</a></li>
              <li><a href="disclaimer.html">Disclaimer</a></li>
              <li><a href="sitemap.html">Sitemap</a></li>
              <li><a href="property-details.html?id=rab-bluestone-city">RAB Bluestone City</a></li>
              <li><a href="property-details.html?id=rab-green-residency">RAB Green Residency</a></li>
              <li><a href="property-details.html?id=rab-elite-enclave">RAB Elite Enclave</a></li>
            </ul>
          </div>

          <div class="footer-col">
            <h5>Get in Touch</h5>
            <div class="footer-contact-item">
              <i class="fa-solid fa-building"></i>
              <div><strong>Head Office</strong>${BRAND.head}</div>
            </div>
            <div class="footer-contact-item">
              <i class="fa-solid fa-location-dot"></i>
              <div><strong>Branch Office</strong>${BRAND.branch}</div>
            </div>
            <div class="footer-contact-item">
              <i class="fa-solid fa-phone"></i>
              <div><strong>Phone</strong><a href="tel:${BRAND.phoneRaw}" style="color:rgba(250,247,242,.85)">${BRAND.phone}</a></div>
            </div>
            <div class="footer-contact-item">
              <i class="fa-solid fa-envelope"></i>
              <div><strong>Email</strong><a href="mailto:${BRAND.email}" style="color:rgba(250,247,242,.85)">${BRAND.email}</a></div>
            </div>
            <div class="footer-contact-item">
              <i class="fa-solid fa-id-card"></i>
              <div><strong>CIN</strong>${BRAND.cin}</div>
            </div>
          </div>
        </div>

        <div class="footer-bottom">
          <div>&copy; <span id="year"></span> ${BRAND.full}. All rights reserved.</div>
          <div class="links">
            <a href="privacy-policy.html">Privacy</a>
            <a href="terms.html">Terms</a>
            <a href="disclaimer.html">Disclaimer</a>
            <a href="sitemap.html">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>

    <div class="floating-actions" data-testid="floating-actions">
      <a class="fab fab-call" href="tel:${BRAND.phoneRaw}" aria-label="Call us" data-testid="fab-call-button"><i class="fa-solid fa-phone"></i></a>
      <a class="fab fab-wa" href="https://wa.me/${BRAND.phoneRaw}?text=Hello%20RAB%20Bluestone,%20I%20would%20like%20to%20enquire%20about%20a%20property." target="_blank" rel="noopener" aria-label="WhatsApp" data-testid="fab-whatsapp-button"><i class="fa-brands fa-whatsapp"></i></a>
    </div>`;

  // ---------- Mount layout on load ----------
  $(function () {
    var $topbarHost = $("#site-topbar");
    var $headerHost = $("#site-header");
    var $footerHost = $("#site-footer");

    if ($topbarHost.length) { $topbarHost.replaceWith(topbarHTML); }
    if ($headerHost.length) { $headerHost.replaceWith(headerHTML); }
    if ($footerHost.length) { $footerHost.replaceWith(footerHTML); }

    $("#year").text(new Date().getFullYear());

    // Mobile menu
    $(document).on("click", ".nav-toggle", function () { $(".mobile-menu").addClass("open"); });
    $(document).on("click", ".mm-close, .mobile-menu a", function () { $(".mobile-menu").removeClass("open"); });

    // Scroll effect on header
    $(window).on("scroll", function () {
      if (window.scrollY > 30) $(".site-header").addClass("scrolled");
      else $(".site-header").removeClass("scrolled");
    });

    // Scroll-reveal
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) e.target.classList.add("in"); });
    }, { threshold: 0.12 });
    document.querySelectorAll(".reveal").forEach(function (el) { io.observe(el); });

    // FAQ accordion
    $(document).on("click", ".faq-q", function () {
      var $item = $(this).closest(".faq-item");
      $item.toggleClass("open");
    });

    // Testimonial slider
    initTestimonials();

    // Page-specific renderers
    if (typeof window.RAB_PAGE_INIT === "function") {
      window.RAB_PAGE_INIT();
    }

    // Render homepage modules
    if ($(".js-featured-properties").length) renderFeaturedProperties(".js-featured-properties");
    if ($(".js-latest-blog").length) renderLatestBlog(".js-latest-blog");

    // Property listing
    if ($("#properties-grid").length) {
      renderProperties();
      $(document).on("input change", "#search, #filter-type, #filter-location, #filter-category", renderProperties);
    }

    // Property detail
    if ($("#property-detail-root").length) {
      renderPropertyDetail();
    }

    // Blog listing
    if ($("#blog-grid").length) {
      renderBlogList();
    }

    // Blog single
    if ($("#blog-single-root").length) {
      renderBlogSingle();
    }
  });

  // ---------- Testimonials ----------
  function initTestimonials() {
    var $slider = $(".testimonial-slider");
    if (!$slider.length) return;
    var $items = $slider.find(".testimonial");
    var n = $items.length;
    if (!n) return;
    var idx = 0;
    var $dots = $(".testimonial-dots");
    $dots.empty();
    for (var i = 0; i < n; i++) {
      $dots.append('<button data-i="' + i + '" data-testid="testimonial-dot-' + i + '"></button>');
    }
    function go(i) {
      idx = (i + n) % n;
      $slider.css("transform", "translateX(-" + (idx * 100) + "%)");
      $dots.find("button").removeClass("active").eq(idx).addClass("active");
    }
    $dots.on("click", "button", function () { go(parseInt($(this).attr("data-i"), 10)); });
    go(0);
    setInterval(function () { go(idx + 1); }, 6000);
  }

  // ---------- Property render helpers ----------
  function propertyCard(p) {
    return `
      <article class="property-card reveal" data-testid="property-card-${p.id}">
        <div class="media">
          <img loading="lazy" src="${p.images[0]}" alt="${p.name} - ${p.location}" />
          <span class="badge">${p.badge}</span>
        </div>
        <div class="info">
          <div class="ptype">${p.type}</div>
          <h3>${p.name}</h3>
          <div class="loc"><i class="fa-solid fa-location-dot"></i> ${p.location}</div>
          <p class="desc">${p.short}</p>
          <div class="foot">
            <span class="price">${p.price}</span>
            <a class="view-link" href="property-details.html?id=${p.id}" data-testid="property-view-${p.id}">View Details <i class="fa-solid fa-arrow-right"></i></a>
          </div>
        </div>
      </article>`;
  }

  function renderFeaturedProperties(sel) {
    var html = window.RAB_PROPERTIES.slice(0, 5).map(propertyCard).join("");
    $(sel).html(html);
    observeReveal($(sel).find(".reveal"));
  }

  function observeReveal($els) {
    if (!$els || !$els.length) return;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) e.target.classList.add("in"); });
    }, { threshold: 0.08 });
    $els.each(function () { io.observe(this); });
  }

  function renderProperties() {
    var q = ($("#search").val() || "").toLowerCase().trim();
    var type = $("#filter-type").val() || "";
    var loc = $("#filter-location").val() || "";
    var cat = $("#filter-category").val() || "";

    var list = window.RAB_PROPERTIES.filter(function (p) {
      var matchesQ = !q || (p.name + " " + p.location + " " + p.type).toLowerCase().indexOf(q) >= 0;
      var matchesType = !type || p.type === type;
      var matchesLoc = !loc || p.location.indexOf(loc) >= 0;
      var matchesCat = !cat || p.category === cat;
      return matchesQ && matchesType && matchesLoc && matchesCat;
    });

    if (!list.length) {
      $("#properties-grid").html('<div style="grid-column:1/-1;padding:60px;text-align:center;color:var(--muted);background:#fff;border-radius:14px;border:1px solid var(--line)"><i class="fa-solid fa-magnifying-glass" style="font-size:2.2rem;color:var(--gold-deep);margin-bottom:14px"></i><h3>No properties match your filters</h3><p>Try adjusting your search criteria.</p></div>');
      $("#properties-count").text("0 properties");
      return;
    }
    $("#properties-count").text(list.length + " " + (list.length === 1 ? "property" : "properties") + " found");
    $("#properties-grid").html(list.map(propertyCard).join(""));
    observeReveal($("#properties-grid").find(".reveal"));
  }

  function renderPropertyDetail() {
    var params = new URLSearchParams(window.location.search);
    var id = params.get("id") || (window.RAB_PROPERTIES[0] && window.RAB_PROPERTIES[0].id);
    var p = window.RAB_PROPERTIES.find(function (x) { return x.id === id; });
    if (!p) { window.location.href = "properties.html"; return; }

    document.title = p.name + " - " + p.location + " | RAB Bluestone";

    var galleryThumbs = p.images.map(function (img, i) {
      return `<img class="${i === 0 ? "active" : ""}" data-src="${img}" src="${img}" loading="lazy" alt="${p.name} view ${i+1}" />`;
    }).join("");

    var features = p.features.map(function (f) {
      return `<li><i class="fa-solid fa-circle-check"></i> ${f}</li>`;
    }).join("");

    var amenities = p.amenities.map(function (a) {
      return `<li><i class="fa-solid fa-check"></i> ${a}</li>`;
    }).join("");

    var highlights = p.highlights.map(function (h) {
      return `<div class="highlight"><i class="fa-solid ${h.i}"></i><div class="v">${h.v}</div><div class="k">${h.k}</div></div>`;
    }).join("");

    var related = window.RAB_PROPERTIES.filter(function (x) { return x.id !== p.id; }).slice(0, 3).map(propertyCard).join("");

    $("#property-detail-root").html(`
      <section class="page-banner">
        <div class="container">
          <div class="tag" style="background:rgba(244,197,66,.15);color:var(--gold);margin-bottom:12px;">${p.type}</div>
          <h1>${p.name}</h1>
          <div class="breadcrumb"><a href="index.html">Home</a><span>›</span><a href="properties.html">Properties</a><span>›</span>${p.name}</div>
        </div>
      </section>

      <section class="section">
        <div class="container">
          <div class="detail-grid">
            <div>
              <div class="gallery-main"><img id="gallery-main-img" src="${p.images[0]}" alt="${p.name}" /></div>
              <div class="gallery-thumbs" id="gallery-thumbs">${galleryThumbs}</div>

              <div style="margin-top:48px;">
                <span class="eyebrow">Overview</span>
                <h2 class="section-title">About ${p.name}</h2>
                <hr class="divider-gold" />
                <p style="font-size:1.05rem;line-height:1.85;color:#3a4258;">${p.overview}</p>
              </div>

              <div style="margin-top:48px;">
                <span class="eyebrow">Highlights</span>
                <h2 class="section-title">Project Highlights</h2>
                <hr class="divider-gold" />
                <div class="highlight-grid">${highlights}</div>
              </div>

              <div style="margin-top:48px;">
                <span class="eyebrow">Features</span>
                <h2 class="section-title">Key Features</h2>
                <hr class="divider-gold" />
                <ul class="amenities">${features}</ul>
              </div>

              <div style="margin-top:48px;">
                <span class="eyebrow">Amenities</span>
                <h2 class="section-title">Project Amenities</h2>
                <hr class="divider-gold" />
                <ul class="amenities">${amenities}</ul>
              </div>

              <div style="margin-top:48px;">
                <span class="eyebrow">Location</span>
                <h2 class="section-title">Location Overview</h2>
                <hr class="divider-gold" />
                <p style="font-size:1.05rem;line-height:1.85;color:#3a4258;">${p.locationDesc}</p>
                <div style="margin-top:24px;border-radius:14px;overflow:hidden;border:1px solid var(--line);">
                  <iframe src="https://www.google.com/maps?q=${encodeURIComponent(p.location)}&output=embed" width="100%" height="320" style="border:0;display:block;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" title="${p.location} map"></iframe>
                </div>
              </div>
            </div>

            <aside class="detail-sidebar" data-testid="property-inquiry-form">
              <h3>${p.name}</h3>
              <div style="font-size:.9rem;color:var(--muted);margin-bottom:10px;"><i class="fa-solid fa-location-dot" style="color:var(--gold-deep)"></i> ${p.location}</div>
              <div class="price-row"><span class="p">${p.price}</span></div>

              <h4 style="font-family:var(--font-display);margin-bottom:12px;">Schedule a Site Visit</h4>
              <form action="${BRAND.formAction}" method="POST" class="form-grid" data-testid="property-detail-form">
                <input type="hidden" name="_subject" value="Site Visit Request - ${p.name}" />
                <input type="hidden" name="property" value="${p.name}" />
                <input type="hidden" name="_captcha" value="false" />
                <input type="hidden" name="_template" value="table" />
                <div class="form-field full"><input required name="name" placeholder="Your Name" data-testid="pd-form-name" /></div>
                <div class="form-field full"><input required type="tel" name="phone" placeholder="Phone Number" data-testid="pd-form-phone" /></div>
                <div class="form-field full"><input type="email" name="email" placeholder="Email Address" data-testid="pd-form-email" /></div>
                <div class="form-field full"><input type="date" name="visit_date" data-testid="pd-form-date" /></div>
                <div class="form-field full"><textarea name="message" placeholder="Message (optional)" data-testid="pd-form-message"></textarea></div>
                <div class="form-field full"><button class="btn btn-primary" type="submit" style="width:100%;justify-content:center;" data-testid="pd-form-submit">Request Site Visit <i class="fa-solid fa-arrow-right"></i></button></div>
              </form>

              <div style="margin-top:24px;padding-top:24px;border-top:1px solid var(--line);">
                <a class="btn btn-outline" href="tel:${BRAND.phoneRaw}" style="width:100%;justify-content:center;margin-bottom:10px;" data-testid="pd-call-button"><i class="fa-solid fa-phone"></i> ${BRAND.phone}</a>
                <a class="btn btn-ghost" style="width:100%;justify-content:center;color:var(--navy);border-color:var(--navy);" href="https://wa.me/${BRAND.phoneRaw}?text=Hello%20RAB%20Bluestone,%20I%20am%20interested%20in%20${encodeURIComponent(p.name)}" data-testid="pd-wa-button"><i class="fa-brands fa-whatsapp" style="color:#25D366"></i> WhatsApp Enquiry</a>
              </div>
            </aside>
          </div>

          <div style="margin-top:96px;">
            <div class="section-head"><span class="eyebrow">Explore More</span><h2 class="section-title">Related Properties</h2><hr class="divider-gold"/></div>
            <div class="grid grid-3 md-2">${related}</div>
          </div>
        </div>
      </section>
    `);

    // Gallery thumb click
    $(document).on("click", "#gallery-thumbs img", function () {
      var src = $(this).attr("data-src");
      $("#gallery-main-img").attr("src", src);
      $("#gallery-thumbs img").removeClass("active");
      $(this).addClass("active");
    });
  }

  // ---------- Blog ----------
  function blogCard(b) {
    return `
      <article class="blog-card reveal" data-testid="blog-card-${b.slug}">
        <a href="blog-single.html?slug=${b.slug}" class="media"><img loading="lazy" src="${b.image}" alt="${b.title}" /></a>
        <div class="body">
          <div class="meta"><span>${b.cat}</span> &nbsp;•&nbsp; ${b.date} &nbsp;•&nbsp; ${b.read}</div>
          <h3><a href="blog-single.html?slug=${b.slug}">${b.title}</a></h3>
          <p class="excerpt">${b.excerpt}</p>
          <a class="read" href="blog-single.html?slug=${b.slug}" data-testid="blog-read-${b.slug}">Read article <i class="fa-solid fa-arrow-right"></i></a>
        </div>
      </article>`;
  }

  function renderLatestBlog(sel) {
    var html = window.RAB_BLOG.slice(0, 3).map(blogCard).join("");
    $(sel).html(html);
    observeReveal($(sel).find(".reveal"));
  }

  function renderBlogList() {
    var html = window.RAB_BLOG.map(blogCard).join("");
    $("#blog-grid").html(html);
    observeReveal($("#blog-grid").find(".reveal"));
  }

  function renderBlogSingle() {
    var params = new URLSearchParams(window.location.search);
    var slug = params.get("slug") || (window.RAB_BLOG[0] && window.RAB_BLOG[0].slug);
    var b = window.RAB_BLOG.find(function (x) { return x.slug === slug; });
    if (!b) { window.location.href = "blog.html"; return; }

    document.title = b.title + " | RAB Bluestone Blog";

    var related = window.RAB_BLOG.filter(function (x) { return x.slug !== b.slug; }).slice(0, 3).map(blogCard).join("");

    $("#blog-single-root").html(`
      <section class="page-banner">
        <div class="container">
          <div class="tag" style="background:rgba(244,197,66,.15);color:var(--gold);margin-bottom:12px;">${b.cat}</div>
          <h1 style="max-width:880px;">${b.title}</h1>
          <div class="breadcrumb">
            <a href="index.html">Home</a><span>›</span>
            <a href="blog.html">Blog</a><span>›</span>
            ${b.cat}
          </div>
          <div style="margin-top:24px;color:rgba(255,255,255,.75);font-size:.92rem;">
            <i class="fa-regular fa-calendar"></i> ${b.date} &nbsp;•&nbsp;
            <i class="fa-regular fa-clock"></i> ${b.read} &nbsp;•&nbsp;
            <i class="fa-regular fa-user"></i> RAB Bluestone Team
          </div>
        </div>
      </section>

      <section class="section">
        <div class="container" style="max-width:880px;">
          <div style="border-radius:18px;overflow:hidden;margin-bottom:48px;">
            <img src="${b.image}" alt="${b.title}" style="width:100%;height:auto;display:block;" />
          </div>
          <div class="article-content">${window.RAB_BLOG_BODY}</div>

          <div style="margin-top:48px;padding:32px;background:var(--paper);border-radius:18px;display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;">
            <div>
              <div style="font-family:var(--font-display);font-size:1.3rem;color:var(--navy);">Need expert guidance?</div>
              <p style="margin:6px 0 0;">Talk to our team for tailored advice on your property goals.</p>
            </div>
            <a class="btn btn-primary" href="contact.html" data-testid="blog-contact-cta">Contact Us <i class="fa-solid fa-arrow-right"></i></a>
          </div>
        </div>
      </section>

      <section class="section section--paper">
        <div class="container">
          <div class="section-head"><span class="eyebrow">More Reading</span><h2 class="section-title">Related Articles</h2><hr class="divider-gold"/></div>
          <div class="grid grid-3 md-2">${related}</div>
        </div>
      </section>
    `);
  }

})(jQuery);
